//
//  ToDoListAppTests.swift
//  ToDoListAppTests
//
//  Created by Bünyamin Dağdelen   on 26.12.24.
//

import Testing
@testable import ToDoListApp

struct ToDoListAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
