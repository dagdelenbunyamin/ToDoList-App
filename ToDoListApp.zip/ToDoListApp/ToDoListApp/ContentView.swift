import SwiftUI
import CoreData

struct ContentView: View {
    @FetchRequest(entity: Task.entity(), sortDescriptors: [NSSortDescriptor(keyPath: \Task.dueDate, ascending: true)])
    var tasks: FetchedResults<Task>

    @Environment(\.managedObjectContext) private var viewContext

    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(tasks) { task in
                        NavigationLink(destination: TaskDetailView(task: task)) {
                            HStack {
                                Text(task.title ?? "Untitled Task")
                                    .strikethrough(task.isCompleted, color: .gray)

                                Spacer()

                                Text(task.dueDate ?? Date(), style: .date)
                                    .foregroundColor(.gray)

                                Toggle(isOn: Binding(
                                    get: { task.isCompleted },
                                    set: { newValue in
                                        task.isCompleted = newValue
                                        saveContext()
                                    }
                                )) {
                                    Text("Done")
                                }
                                .labelsHidden()
                            }
                            .padding()
                        }
                    }
                    .onDelete(perform: deleteTasks)
                }
                .listStyle(PlainListStyle()) // For better appearance
            }
            .navigationBarTitle("To-Do List", displayMode: .inline)
            .navigationBarItems(trailing: addButton)
        }
    }

    private var addButton: some View {
        Button(action: addTask) {
            HStack {
                Image(systemName: "plus")
                Text("Add Task")
            }
        }
    }

    private func addTask() {
        let newTask = Task(context: viewContext)
        newTask.title = "New Task"
        newTask.dueDate = Date().addingTimeInterval(86400) // Fälligkeitsdatum einen Tag später
        newTask.isCompleted = false
        saveContext()
    }

    private func deleteTasks(offsets: IndexSet) {
        withAnimation {
            offsets.map { tasks[$0] }.forEach(viewContext.delete)
            saveContext()
        }
    }

    private func saveContext() {
        do {
            try viewContext.save()
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
}
