import SwiftUI
import CoreData

struct FavoriteTasksView: View {
    @FetchRequest(entity: Task.entity(), sortDescriptors: [NSSortDescriptor(keyPath: \Task.dueDate, ascending: true)])
    var tasks: FetchedResults<Task>

    @Environment(\.managedObjectContext) private var viewContext

    var body: some View {
        NavigationView {
            List {
                ForEach(tasks.filter { $0.isFavorite }) { task in
                    NavigationLink(destination: TaskDetailView(task: task)) {
                        HStack {
                            Text(task.title ?? "Untitled Task")
                                .strikethrough(task.isCompleted, color: .gray)
                            
                            Spacer()
                            
                            Text(task.dueDate ?? Date(), style: .date)
                                .foregroundColor(.gray)
                        }
                        .padding()
                    }
                }
                .onDelete(perform: deleteTasks)
            }
            .navigationBarTitle("Favorites")
        }
    }

    private func deleteTasks(offsets: IndexSet) {
        withAnimation {
            offsets.map { tasks[$0] }.forEach(viewContext.delete)
            saveContext()
        }
    }

    private func saveContext() {
        do {
            try viewContext.save()
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
}
