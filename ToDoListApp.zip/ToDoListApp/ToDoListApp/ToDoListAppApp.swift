import SwiftUI

@main
struct ToDoListAppApp: App {
    @AppStorage("isDarkMode") private var isDarkMode: Bool = false
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            NavigationView {
                TabView {
                    ToDoListView()
                        .tabItem {
                            Image(systemName: "list.dash")
                            Text("To-Do List")
                        }

                    FavoriteTasksView()
                        .tabItem {
                            Image(systemName: "star.fill")
                            Text("Favorites")
                        }

                    SettingsView()
                        .tabItem {
                            Image(systemName: "gearshape.fill")
                            Text("Settings")
                        }
                }
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
                .preferredColorScheme(isDarkMode ? .dark : .light) // Setze den gesamten App-Darkmode
            }
            .onOpenURL { url in
                if let scheme = url.scheme, scheme == "myapp" {
                    // Hier kannst du dann die Logik zum Öffnen des PDF oder einer anderen Aktion einfügen
                    print("URL geöffnet: \(url)")
                    // Zum Beispiel das Öffnen eines PDFs:
                    if url.host == "pdfview" {
                        // Logik, um das PDF zu öffnen, basierend auf der URL
                    }
                }
            }
        }
    }
}
