import SwiftUI
import CoreData

struct TaskDetailView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @ObservedObject var task: Task

    @State private var title: String
    @State private var dueDate: Date
    @State private var isFavorite: Bool

    init(task: Task) {
        self.task = task
        _title = State(initialValue: task.title ?? "")
        _dueDate = State(initialValue: task.dueDate ?? Date())
        _isFavorite = State(initialValue: task.isFavorite)
    }

    var body: some View {
        Form {
            Section(header: Text("Task Details")) {
                TextField("Task Title", text: $title)
                DatePicker("Due Date", selection: $dueDate, displayedComponents: .date)

                Toggle(isOn: $isFavorite) {
                    Text("Favorite")
                }
            }

            Section {
                Button("Save Changes") {
                    task.title = title
                    task.dueDate = dueDate
                    task.isFavorite = isFavorite
                    saveContext()
                }
                .foregroundColor(.blue)
            }
        }
        .navigationBarTitle("Task Details", displayMode: .inline)
    }

    private func saveContext() {
        do {
            try viewContext.save()
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
}
