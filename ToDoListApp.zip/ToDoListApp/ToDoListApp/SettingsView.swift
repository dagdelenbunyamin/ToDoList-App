import SwiftUI

// 1. IdentifiableImage Typ
struct IdentifiableImage: Identifiable {
    var id = UUID()
    var name: String
}

// 2. FeatureView für jedes Feature mit einem Button, der das Bild anzeigt
struct FeatureView: View {
    var title: String
    var imageName: String
    @Binding var selectedImage: IdentifiableImage?

    var body: some View {
        VStack(spacing: 16) {
            // Titel
            Text(title)
                .font(.headline)
                .foregroundColor(.blue)
                .padding(.bottom, 8)

            // Bild mit Tap-Geste
            
            // Button, um das Bild im Vollbildmodus anzuzeigen
            Button(action: {
                selectedImage = IdentifiableImage(name: imageName)
            }) {
                HStack {
                    Image(systemName: "photo.fill")
                    Text("View Full Image")
                }
                .font(.body)
                .foregroundColor(.white)
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(Color.blue)
                .cornerRadius(8)
            }
            .padding(.top, 8)

            // Hinweis für weitere Informationen
            Text("Tap the image for more details.")
                .font(.footnote)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
                .padding(.top, 8)
        }
        .padding()
        .background(Color(UIColor.secondarySystemBackground))
        .cornerRadius(10)
    }
}

// 3. FullScreenImageView für das Anzeigen eines Bildes im Vollbildmodus
struct FullScreenImageView: View {
    var imageName: String

    var body: some View {
        VStack {
            Image(imageName)
                .resizable()
                .scaledToFit()
                .edgesIgnoringSafeArea(.all)
                .onTapGesture {
                    // Schließt das Vollbild beim Tippen auf das Bild
                    UIApplication.shared.windows.first?.rootViewController?.dismiss(animated: true)
                }
        }
    }
}

// 4. SettingsView mit FeatureView und Image-Anzeige
struct SettingsView: View {
    @AppStorage("isDarkMode") private var isDarkMode: Bool = false
    @State private var selectedImage: IdentifiableImage? = nil

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    // Appearance Section
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Appearance")
                            .font(.headline)
                            .foregroundColor(.blue)

                        Toggle(isOn: $isDarkMode) {
                            Label("Dark Mode", systemImage: isDarkMode ? "moon.fill" : "sun.max.fill")
                                .foregroundColor(.primary)
                                .font(.subheadline)
                        }
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                        .padding()
                        .background(Color(UIColor.secondarySystemBackground))
                        .cornerRadius(10)
                    }
                    .padding(.horizontal)

                    // About Section
                    VStack(alignment: .leading, spacing: 8) {
                        Text("About")
                            .font(.headline)
                            .foregroundColor(.blue)

                        Text("ToDoListApp is a task manager that helps you organize your daily tasks efficiently.")
                            .font(.body)
                            .foregroundColor(.gray)

                        Text("Version: 1.0")
                            .font(.footnote)
                            .foregroundColor(.gray)
                            .padding(.bottom, 8)

                        Divider()

                        // Features mit Bildern
                        VStack(spacing: 24) {  // Erhöhte Spacing für bessere Lesbarkeit
                            FeatureView(
                                title: "Feature 1",
                                imageName: "ToDoListApp – App Beschreibung 1", // Stelle sicher, dass dies ein gültiger Bildname ist
                                selectedImage: $selectedImage
                            )
                            .padding(.bottom, 16)  // Zusätzlicher Abstand für bessere Trennung

                            FeatureView(
                                title: "Feature 2",
                                imageName: "ToDoListApp – App Beschreibung 2", // Stelle sicher, dass dies ein gültiger Bildname ist
                                selectedImage: $selectedImage
                            )
                        }
                    }
                    .padding(.horizontal)

                    // Support Section
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("Support")
                                .font(.headline)
                                .foregroundColor(.blue)

                            Spacer()

                            Button(action: {
                                if let url = URL(string: "mailto:support@example.com") {
                                    UIApplication.shared.open(url)
                                }
                            }) {
                                Label("Contact Us", systemImage: "envelope.fill")
                                    .font(.body)
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .background(Color.blue)
                                    .cornerRadius(8)
                            }
                        }
                        .padding()
                        .background(Color(UIColor.secondarySystemBackground))
                        .cornerRadius(10)
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical)
            }
            .background(Color(UIColor.systemGroupedBackground).edgesIgnoringSafeArea(.all))
            .navigationTitle("Settings")
            .fullScreenCover(item: $selectedImage) { image in
                FullScreenImageView(imageName: image.name)
            }
        }
    }
}
