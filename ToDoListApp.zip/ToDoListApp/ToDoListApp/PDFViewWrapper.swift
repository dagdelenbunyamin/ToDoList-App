import SwiftUI
import PDFKit

struct PDFViewWrapper: View {
    var body: some View {
        PDFKitView()
            .edgesIgnoringSafeArea(.all)
    }
}

struct PDFKitView: UIViewRepresentable {
    func makeUIView(context: Context) -> PDFView {
        let pdfView = PDFView()
        
        // Den Dateinamen mit den korrekten Zeichen anpassen
        if let url = Bundle.main.url(forResource: "ToDoListApp – App Beschreibung", withExtension: "pdf") {
            let document = PDFDocument(url: url)
            pdfView.document = document
        }
        
        pdfView.autoScales = true
        return pdfView
    }

    func updateUIView(_ uiView: PDFView, context: Context) {}
}
